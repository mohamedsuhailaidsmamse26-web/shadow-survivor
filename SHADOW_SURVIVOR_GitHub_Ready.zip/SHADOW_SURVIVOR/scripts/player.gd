extends CharacterBody3D

@export var move_speed: float = 5.5
@export var run_speed: float = 8.0
@export var jump_velocity: float = 4.5
@export var gravity: float = 18.0

var touch_direction := Vector2.ZERO
var run_requested := false
var jump_requested := false

func _ready() -> void:
    _setup_keyboard_controls()

func _setup_keyboard_controls() -> void:
    _add_key_action("move_forward", KEY_W)
    _add_key_action("move_back", KEY_S)
    _add_key_action("move_left", KEY_A)
    _add_key_action("move_right", KEY_D)
    _add_key_action("run", KEY_SHIFT)

func _add_key_action(action_name: String, key_code: Key) -> void:
    if not InputMap.has_action(action_name):
        InputMap.add_action(action_name)
    var event := InputEventKey.new()
    event.physical_keycode = key_code
    InputMap.action_add_event(action_name, event)

func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y -= gravity * delta
    elif jump_requested:
        velocity.y = jump_velocity
    jump_requested = false

    var input_vector := Vector2.ZERO
    input_vector.x = Input.get_action_strength("move_right") - Input.get_action_strength("move_left")
    input_vector.y = Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
    input_vector += touch_direction
    input_vector = input_vector.limit_length(1.0)

    var speed := run_speed if run_requested or Input.is_action_pressed("run") else move_speed
    var direction := Vector3(input_vector.x, 0, input_vector.y)
    direction = direction.rotated(Vector3.UP, 0.0)

    velocity.x = direction.x * speed
    velocity.z = direction.z * speed

    if direction.length() > 0.05:
        var target_angle := atan2(direction.x, direction.z)
        rotation.y = lerp_angle(rotation.y, target_angle, 10.0 * delta)

    move_and_slide()

func set_touch_direction(value: Vector2) -> void:
    touch_direction = value

func set_run(value: bool) -> void:
    run_requested = value

func request_jump() -> void:
    jump_requested = true
