extends CanvasLayer

var player: CharacterBody3D
var status_label: Label

func _ready() -> void:
    player = get_parent().get_node("Player")
    _build_controls()

func _build_controls() -> void:
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(root)

    status_label = Label.new()
    status_label.text = "SHADOW SURVIVOR  |  EXPLORATION PROTOTYPE"
    status_label.position = Vector2(18, 16)
    status_label.add_theme_font_size_override("font_size", 18)
    root.add_child(status_label)

    var hint := Label.new()
    hint.text = "Explore the test world"
    hint.position = Vector2(18, 44)
    hint.add_theme_font_size_override("font_size", 14)
    root.add_child(hint)

    var controls := [
        ["◀", Vector2(24, -118), Vector2(-1, 0)],
        ["▶", Vector2(164, -118), Vector2(1, 0)],
        ["▲", Vector2(94, -188), Vector2(0, -1)],
        ["▼", Vector2(94, -48), Vector2(0, 1)]
    ]
    for item in controls:
        var button := TouchScreenButton.new()
        var shape := RectangleShape2D.new()
        shape.size = Vector2(62, 62)
        button.shape = shape
        button.position = Vector2(118, get_viewport().get_visible_rect().size.y - 118) + item[1]
        button.visibility_mode = TouchScreenButton.VISIBILITY_ALWAYS
        button.action = ""
        root.add_child(button)
        button.set_meta("direction", item[2])

        var visual := Label.new()
        visual.text = item[0]
        visual.position = button.position - Vector2(15, 22)
        visual.add_theme_font_size_override("font_size", 28)
        visual.mouse_filter = Control.MOUSE_FILTER_IGNORE
        root.add_child(visual)
        button.pressed.connect(func(): player.set_touch_direction(item[2]))
        button.released.connect(func(): player.set_touch_direction(Vector2.ZERO))

    var run_button := Button.new()
    run_button.text = "RUN"
    run_button.position = Vector2(get_viewport().get_visible_rect().size.x - 142, get_viewport().get_visible_rect().size.y - 110)
    run_button.size = Vector2(112, 52)
    root.add_child(run_button)
    run_button.button_down.connect(func(): player.set_run(true))
    run_button.button_up.connect(func(): player.set_run(false))

    var jump_button := Button.new()
    jump_button.text = "JUMP"
    jump_button.position = Vector2(get_viewport().get_visible_rect().size.x - 142, get_viewport().get_visible_rect().size.y - 174)
    jump_button.size = Vector2(112, 52)
    root.add_child(jump_button)
    jump_button.pressed.connect(func(): player.request_jump())
