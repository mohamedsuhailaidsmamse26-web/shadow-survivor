extends Node3D

func _ready() -> void:
    _create_environment()
    _create_ground()
    _create_landmarks()

func _create_environment() -> void:
    var env := WorldEnvironment.new()
    var environment := Environment.new()
    environment.background_mode = Environment.BG_SKY
    environment.sky = Sky.new()
    environment.sky.sky_material = ProceduralSkyMaterial.new()
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color(0.48, 0.55, 0.65)
    environment.ambient_light_energy = 0.65
    env.environment = environment
    add_child(env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -32, 0)
    sun.light_energy = 1.15
    sun.shadow_enabled = true
    add_child(sun)

func _create_ground() -> void:
    var ground := StaticBody3D.new()
    ground.name = "Ground"
    add_child(ground)

    var mesh_instance := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(180, 180)
    mesh_instance.mesh = plane
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.16, 0.23, 0.19)
    mat.roughness = 1.0
    mesh_instance.material_override = mat
    ground.add_child(mesh_instance)

    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3(180, 0.2, 180)
    collision.shape = shape
    collision.position.y = -0.1
    ground.add_child(collision)

func _create_landmarks() -> void:
    # Simple placeholder structures to establish scale; replace with licensed assets later.
    for i in range(12):
        var building := MeshInstance3D.new()
        var box := BoxMesh.new()
        var height := 3.0 + float((i * 7) % 9)
        box.size = Vector3(3.5, height, 3.5)
        building.mesh = box
        building.position = Vector3(float((i % 4) - 2) * 13.0, height / 2.0, float((i / 4) - 1) * 16.0 - 18.0)
        var material := StandardMaterial3D.new()
        material.albedo_color = Color(0.20 + float(i % 3) * 0.04, 0.24, 0.29)
        material.roughness = 0.9
        building.material_override = material
        add_child(building)
