# SHADOW SURVIVOR

A new Godot 4.7 project for an original third-person open-world survival **exploration prototype**.

## Current milestone
- 3D test environment and lighting
- Third-person capsule placeholder player
- Basic walking, running and jumping
- Simple on-screen touch controls
- Keyboard input can be added/configured in the next milestone

## Important
This is a starter prototype, **not** a finished AAA game and does not yet contain realistic human models, vehicles, missions, advanced terrain, or optimized mobile graphics. Those need to be added and tested in later milestones. The capsule is only a temporary placeholder.

## Open in Godot
1. Download and extract this repository.
2. In Godot Project Manager choose **Import**.
3. Select the `project.godot` file inside this folder.
4. Open the project and press Play.

## Repository structure
```text
SHADOW_SURVIVOR/
├── project.godot
├── scenes/
│   └── main.tscn
├── scripts/
│   ├── player.gd
│   ├── world.gd
│   └── hud.gd
└── README.md
```

## Next milestones
1. Verify this prototype runs on the target Android device.
2. Add camera look controls and proper keyboard input map.
3. Replace placeholder player with a properly licensed animated character.
4. Build terrain, foliage, roads and buildings with mobile performance in mind.
5. Add original story and non-graphic survival systems.
6. Test Android and PC exports separately.

## Credits and licensing
All scripts and scene setup in this starter project are original. Any third-party models, textures, sounds or animations added later must have a license suitable for the intended distribution and must be credited where required.
